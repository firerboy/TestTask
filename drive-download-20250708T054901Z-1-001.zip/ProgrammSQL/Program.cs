﻿using System;
using System.Collections.Generic;
using Npgsql;
using OfficeOpenXml;
public class Customer
{
    public int Id { get; set; }
    public string CardCode { get; set; }
    public string LastName { get; set; }
    public string FirstName { get; set; }
    public string SurName { get; set; }
    public string PhoneMobile { get; set; }
    public string Email { get; set; }
    public int? GenderId { get; set; }
    public DateTime? Birthday { get; set; }
    public string City { get; set; }
    public string PinCode { get; set; }
    public decimal? Bonus { get; set; }
    public decimal? Turnover { get; set; }
}

class Program
{
    private static string connectionString = "Host=localhost;Port=5432;Database=ClientBD;Username=postgres;Password=Qwertyaswer12";

    static void Main(string[] args)
    {
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        while (true)
        {
            Console.Clear();
            Console.WriteLine("1. Импорт данных из Excel");
            Console.WriteLine("2. Просмотр и редактирование данных");
            Console.WriteLine("3. Добавить нового клиента");
            Console.WriteLine("4. Выход");
            Console.WriteLine("Выберите действие:");

            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    ImportDataFromExcel();
                    break;
                case "2":
                    ViewAndEditData();
                    break;
                case "3":
                    AddNewCustomer();
                    break;
                case "4":
                    return;
                default:
                    Console.WriteLine("Неверный выбор, попробуйте еще раз");
                    Console.ReadKey();
                    break;
            }
        }
    }

    static void ImportDataFromExcel()
    {
        Console.Clear();
        Console.WriteLine("Введите путь к файлу Excel:");
        string filePath = Console.ReadLine();

        try
        {
            var customers = ReadCustomersFromExcel(filePath);
            CreateTableIfNotExists();
            InsertCustomersToDatabase(customers);
            Console.WriteLine($"Успешно импортировано {customers.Count} записей.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
        Console.ReadKey();
    }

    static List<Customer> ReadCustomersFromExcel(string filePath)
    {
        var customers = new List<Customer>();

        using (var package = new ExcelPackage(new System.IO.FileInfo(filePath)))
        {
            var worksheet = package.Workbook.Worksheets[0];
            int rowCount = worksheet.Dimension.Rows;

            for (int row = 2; row <= rowCount; row++)
            {
                try
                {
                    var customer = new Customer
                    {
                        CardCode = worksheet.Cells[row, 1].Text,
                        LastName = worksheet.Cells[row, 2].Text,
                        FirstName = worksheet.Cells[row, 3].Text,
                        SurName = worksheet.Cells[row, 4].Text,
                        PhoneMobile = worksheet.Cells[row, 5].Text,
                        Email = worksheet.Cells[row, 6].Text,
                        GenderId = ParseInt(worksheet.Cells[row, 7].Text),
                        Birthday = ParseDate(worksheet.Cells[row, 8].Text),
                        City = worksheet.Cells[row, 9].Text,
                        PinCode = worksheet.Cells[row, 10].Text,
                        Bonus = ParseDecimal(worksheet.Cells[row, 11].Text),
                        Turnover = ParseDecimal(worksheet.Cells[row, 12].Text)
                    };

                    customers.Add(customer);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при чтении строки {row}: {ex.Message}");
                }
            }
        }

        return customers;
    }

    static void CreateTableIfNotExists()
    {
        using (var conn = new NpgsqlConnection(connectionString))
        {
            conn.Open();

            var cmd = new NpgsqlCommand(@"
                CREATE TABLE IF NOT EXISTS Customers (
                    Id SERIAL PRIMARY KEY,
                    CardCode TEXT,
                    LastName TEXT,
                    FirstName TEXT,
                    SurName TEXT,
                    PhoneMobile TEXT,
                    Email TEXT,
                    GenderId INTEGER,
                    Birthday DATE,
                    City TEXT,
                    PinCode TEXT,
                    Bonus DECIMAL(18,2),
                    Turnover DECIMAL(18,2),
                    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )", conn);

            cmd.ExecuteNonQuery();
        }
    }

    static void InsertCustomersToDatabase(List<Customer> customers)
    {
        using (var conn = new NpgsqlConnection(connectionString))
        {
            conn.Open();

            using (var transaction = conn.BeginTransaction())
            {
                try
                {
                    var clearCmd = new NpgsqlCommand("DELETE FROM Customers", conn, transaction);
                    clearCmd.ExecuteNonQuery();

                    foreach (var customer in customers)
                    {
                        var cmd = new NpgsqlCommand(@"
                            INSERT INTO Customers (
                                CardCode, LastName, FirstName, SurName, PhoneMobile, 
                                Email, GenderId, Birthday, City, PinCode, Bonus, Turnover
                            ) VALUES (
                                @CardCode, @LastName, @FirstName, @SurName, @PhoneMobile, 
                                @Email, @GenderId, @Birthday, @City, @PinCode, @Bonus, @Turnover
                            )", conn, transaction);

                        cmd.Parameters.AddWithValue("CardCode", customer.CardCode ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("LastName", customer.LastName ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("FirstName", customer.FirstName ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("SurName", customer.SurName ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("PhoneMobile", customer.PhoneMobile ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("Email", customer.Email ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("GenderId", customer.GenderId ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("Birthday", customer.Birthday ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("City", customer.City ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("PinCode", customer.PinCode ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("Bonus", customer.Bonus ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("Turnover", customer.Turnover ?? (object)DBNull.Value);

                        cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
    }

    static void ViewAndEditData()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("Просмотр и редактирование данных");

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                var countCmd = new NpgsqlCommand("SELECT COUNT(*) FROM Customers", conn);
                int totalCount = Convert.ToInt32(countCmd.ExecuteScalar());

                Console.WriteLine($"Всего записей: {totalCount}");
                Console.WriteLine("Введите количество записей для отображения (или 0 для выхода):");
                string pageSizeInput = Console.ReadLine();

                if (pageSizeInput == "0") return;

                int pageSize = int.Parse(pageSizeInput);

                Console.WriteLine("Введите номер страницы:");
                int pageNumber = int.Parse(Console.ReadLine());

                var cmd = new NpgsqlCommand(
                    "SELECT Id, CardCode, LastName, FirstName, PhoneMobile, Email FROM Customers " +
                    "ORDER BY Id LIMIT @PageSize OFFSET @Offset", conn);

                cmd.Parameters.AddWithValue("PageSize", pageSize);
                cmd.Parameters.AddWithValue("Offset", (pageNumber - 1) * pageSize);

                using (var reader = cmd.ExecuteReader())
                {
                    Console.WriteLine("ID | CardCode | LastName | FirstName | PhoneMobile | Email");
                    Console.WriteLine(new string('-', 80));

                    while (reader.Read())
                    {
                        Console.WriteLine($"{reader["Id"]} | {reader["CardCode"]} | {reader["LastName"]} | " +
                                        $"{reader["FirstName"]} | {reader["PhoneMobile"]} | {reader["Email"]}");
                    }
                }

                Console.WriteLine("\nВведите ID записи для редактирования (или 0 для возврата):");
                string idInput = Console.ReadLine();

                if (idInput == "0") return;

                int id = int.Parse(idInput);
                EditCustomer(id);
            }
        }
    }

    static void EditCustomer(int id)
    {
        Customer customer;
        using (var conn = new NpgsqlConnection(connectionString))
        {
            conn.Open();

            var cmd = new NpgsqlCommand("SELECT * FROM Customers WHERE Id = @Id", conn);
            cmd.Parameters.AddWithValue("Id", id);

            using (var reader = cmd.ExecuteReader())
            {
                if (!reader.Read())
                {
                    Console.WriteLine("Запись не найдена");
                    Console.ReadKey();
                    return;
                }

                customer = new Customer
                {
                    Id = id,
                    CardCode = reader["CardCode"] as string,
                    LastName = reader["LastName"] as string,
                    FirstName = reader["FirstName"] as string,
                    SurName = reader["SurName"] as string,
                    PhoneMobile = reader["PhoneMobile"] as string,
                    Email = reader["Email"] as string,
                    GenderId = reader["GenderId"] as int?,
                    Birthday = reader["Birthday"] as DateTime?,
                    City = reader["City"] as string,
                    PinCode = reader["PinCode"] as string,
                    Bonus = reader["Bonus"] as decimal?,
                    Turnover = reader["Turnover"] as decimal?
                };
            }
        }

        Console.WriteLine("\nТекущие данные:");
        Console.WriteLine($"1. CardCode: {customer.CardCode}");
        Console.WriteLine($"2. LastName: {customer.LastName}");
        Console.WriteLine($"3. FirstName: {customer.FirstName}");
        Console.WriteLine($"4. SurName: {customer.SurName}");
        Console.WriteLine($"5. PhoneMobile: {customer.PhoneMobile}");
        Console.WriteLine($"6. Email: {customer.Email}");
        Console.WriteLine($"7. GenderId: {customer.GenderId}");
        Console.WriteLine($"8. Birthday: {customer.Birthday?.ToShortDateString()}");
        Console.WriteLine($"9. City: {customer.City}");
        Console.WriteLine($"10. PinCode: {customer.PinCode}");
        Console.WriteLine($"11. Bonus: {customer.Bonus}");
        Console.WriteLine($"12. Turnover: {customer.Turnover}");

        Console.WriteLine("\nВведите номер поля для редактирования (или 0 для отмены):");
        string fieldInput = Console.ReadLine();

        if (fieldInput == "0") return;

        int fieldNumber = int.Parse(fieldInput);

        if (fieldNumber < 1 || fieldNumber > 12)
        {
            Console.WriteLine("Неверный номер поля");
            Console.ReadKey();
            return;
        }

        Console.WriteLine("Введите новое значение:");
        string newValue = Console.ReadLine();

        string fieldName = fieldNumber switch
        {
            1 => "CardCode",
            2 => "LastName",
            3 => "FirstName",
            4 => "SurName",
            5 => "PhoneMobile",
            6 => "Email",
            7 => "GenderId",
            8 => "Birthday",
            9 => "City",
            10 => "PinCode",
            11 => "Bonus",
            12 => "Turnover",
            _ => throw new ArgumentException("Неверный номер поля")
        };

        using (var conn = new NpgsqlConnection(connectionString))
        {
            conn.Open();

            var cmd = new NpgsqlCommand(
                $"UPDATE Customers SET {fieldName} = @Value WHERE Id = @Id", conn);

            cmd.Parameters.AddWithValue("Id", id);

            if (fieldNumber == 7)
            {
                cmd.Parameters.AddWithValue("Value", int.Parse(newValue));
            }
            else if (fieldNumber == 8)
            {
                cmd.Parameters.AddWithValue("Value", DateTime.Parse(newValue));
            }
            else if (fieldNumber == 11 || fieldNumber == 12)
            {
                cmd.Parameters.AddWithValue("Value", decimal.Parse(newValue));
            }
            else
            {
                cmd.Parameters.AddWithValue("Value", newValue);
            }

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                Console.WriteLine("Данные успешно обновлены");
            }
            else
            {
                Console.WriteLine("Не удалось обновить данные");
            }
        }

        Console.ReadKey();
    }

    static void AddNewCustomer()
    {
        Console.Clear();
        Console.WriteLine("Добавление нового клиента");

        var customer = new Customer();

        Console.Write("CardCode: ");
        customer.CardCode = Console.ReadLine();

        Console.Write("Фамилия: ");
        customer.LastName = Console.ReadLine();

        Console.Write("Имя: ");
        customer.FirstName = Console.ReadLine();

        Console.Write("Отчество: ");
        customer.SurName = Console.ReadLine();

        Console.Write("Мобильный телефон: ");
        customer.PhoneMobile = Console.ReadLine();

        Console.Write("Email: ");
        customer.Email = Console.ReadLine();

        Console.Write("Пол (1-М, 2-Ж): ");
        customer.GenderId = int.Parse(Console.ReadLine());

        Console.Write("Дата рождения (гггг-мм-дд): ");
        customer.Birthday = DateTime.Parse(Console.ReadLine());

        Console.Write("Город: ");
        customer.City = Console.ReadLine();

        Console.Write("Пин-код: ");
        customer.PinCode = Console.ReadLine();

        Console.Write("Бонусы: ");
        customer.Bonus = decimal.Parse(Console.ReadLine());

        Console.Write("Оборот: ");
        customer.Turnover = decimal.Parse(Console.ReadLine());

        using (var conn = new NpgsqlConnection(connectionString))
        {
            conn.Open();

            var cmd = new NpgsqlCommand(@"
                INSERT INTO Customers (
                    CardCode, LastName, FirstName, SurName, PhoneMobile, 
                    Email, GenderId, Birthday, City, PinCode, Bonus, Turnover
                ) VALUES (
                    @CardCode, @LastName, @FirstName, @SurName, @PhoneMobile, 
                    @Email, @GenderId, @Birthday, @City, @PinCode, @Bonus, @Turnover
                )", conn);

            cmd.Parameters.AddWithValue("CardCode", customer.CardCode ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("LastName", customer.LastName ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("FirstName", customer.FirstName ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("SurName", customer.SurName ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("PhoneMobile", customer.PhoneMobile ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("Email", customer.Email ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("GenderId", customer.GenderId ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("Birthday", customer.Birthday ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("City", customer.City ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("PinCode", customer.PinCode ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("Bonus", customer.Bonus ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("Turnover", customer.Turnover ?? (object)DBNull.Value);

            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                Console.WriteLine("Клиент успешно добавлен!");
            }
            else
            {
                Console.WriteLine("Не удалось добавить клиента");
            }
        }

        Console.WriteLine("Нажмите любую клавишу для продолжения...");
        Console.ReadKey();
    }

    // Вспомогательные методы для парсинга
    static int? ParseInt(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        return int.TryParse(value, out int result) ? result : (int?)null;
    }

    static DateTime? ParseDate(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        return DateTime.TryParse(value, out DateTime result) ? result : (DateTime?)null;
    }

    static decimal? ParseDecimal(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        return decimal.TryParse(value, out decimal result) ? result : (decimal?)null;
    }
}